package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

import java.net.URL;
import java.util.ResourceBundle;

public class Controller implements Initializable{

    @FXML private Button btnLoad;
    @FXML private Button btnPlay;
    @FXML private Button btnPause;
    @FXML private Button btnStop;
    @FXML private TextField path;

    public String filePath;
    public Media hit;
    public MediaPlayer mediaPlayer;



    @Override
    public void initialize(URL location, ResourceBundle resources){

        btnLoad.setOnAction(event->setBtnLoad(event));
        btnPlay.setOnAction(event->setBtnPlay(event));
        btnPause.setOnAction(event->setBtnPause(event));
        btnStop.setOnAction(event->setBtnStop(event));
    }

    public void setBtnLoad(ActionEvent event){
        filePath = path.getText();
        hit = new Media(filePath);
        mediaPlayer = new MediaPlayer(hit);
    }

    public void setBtnPlay(ActionEvent event){
        mediaPlayer.play();
    }

    public void setBtnPause(ActionEvent event){
        mediaPlayer.pause();
    }

    public void setBtnStop(ActionEvent event){
        mediaPlayer.stop();
    }


}
